# GOAL-X AI V2.1 PRO SIGNAL

Bu sürüm:
- Canlı maçları ülke ve lig bazında ayırır.
- API-Football canlı skorlarını gösterir.
- Canlı maçların sağlayıcı tarafından sunulan tüm takım istatistiklerini ayrıntıda gösterir.
- Şut, isabetli şut, ceza sahası şutu, korner, topa sahip olma, xG ve kartlardan GOAL-X 0-100 baskı/gol sinyal endeksi üretir.
- 70+ sinyalleri ayrı filtreleyebilir.
- API günlük kotasını gösterir ve kota azaldığında yenilemeyi otomatik yavaşlatır.
- API anahtarını yalnızca cihazdaki SharedPreferences alanında saklar; kaynak koda yazmaz.

Not: GOAL-X sinyali bir olasılık ya da gol garantisi değildir. Veri sağlayıcının eksik bıraktığı istatistikler uygulamada “—” görünür.
