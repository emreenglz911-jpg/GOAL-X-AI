package com.goalxai.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

private val Gold = Color(0xFFD4AF37)
private val Bg = Color(0xFF0B0F14)
private val CardBg = Color(0xFF151B22)
private val SoftCard = Color(0xFF10161D)
private val Green = Color(0xFF67D391)
private val Orange = Color(0xFFFFB74D)
private val Red = Color(0xFFFF6B6B)

private const val LIVE_REFRESH_MS = 300_000L
private const val STATS_REFRESH_MS = 1_800_000L
private const val EMPTY_STATS_RETRY_MS = 7_200_000L

data class LiveMatch(
    val id: Int,
    val league: String,
    val country: String,
    val homeId: Int,
    val awayId: Int,
    val home: String,
    val away: String,
    val homeGoals: Int?,
    val awayGoals: Int?,
    val minute: Int,
    val status: String,
    val events: List<MatchEvent> = emptyList()
)

data class ApiQuota(val remaining: Int?, val limit: Int?)
data class LiveResult(val matches: List<LiveMatch>, val quota: ApiQuota)

data class TeamStats(
    val teamId: Int,
    val teamName: String,
    val values: Map<String, String?>
)

data class MatchEvent(
    val minute: Int,
    val team: String,
    val player: String,
    val type: String,
    val detail: String
)

data class GoalSignal(
    val score: Int,
    val label: String,
    val leader: String,
    val homePressure: Int,
    val awayPressure: Int,
    val reasons: List<String>
)

data class MatchDetail(
    val homeStats: TeamStats?,
    val awayStats: TeamStats?,
    val events: List<MatchEvent>,
    val signal: GoalSignal?,
    val updatedAt: Long,
    val statsAvailable: Boolean
)

data class DetailResult(
    val details: Map<Int, MatchDetail>,
    val quota: ApiQuota,
    val coveredMatches: Int
)

data class ApiJson(val root: JSONObject, val quota: ApiQuota)

private fun requestJson(url: String, apiKey: String): ApiJson {
    val c = (URL(url).openConnection() as HttpURLConnection).apply {
        requestMethod = "GET"
        setRequestProperty("x-apisports-key", apiKey)
        connectTimeout = 15_000
        readTimeout = 15_000
    }
    val code = c.responseCode
    val remaining = c.getHeaderField("x-ratelimit-requests-remaining")?.toIntOrNull()
    val limit = c.getHeaderField("x-ratelimit-requests-limit")?.toIntOrNull()
    val stream = if (code in 200..299) c.inputStream else c.errorStream
    val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
    if (code !in 200..299) error("API hatası ($code)")
    val root = JSONObject(body)
    val errors = root.opt("errors")
    if (errors != null && errors != JSONObject.NULL) {
        val text = errors.toString()
        if (text != "{}" && text != "[]" && text.isNotBlank()) {
            error("API: $text")
        }
    }
    return ApiJson(root, ApiQuota(remaining, limit))
}

private fun fetchLive(apiKey: String): LiveResult {
    val r = requestJson("https://v3.football.api-sports.io/fixtures?live=all", apiKey)
    val arr = r.root.optJSONArray("response") ?: JSONArray()
    val out = mutableListOf<LiveMatch>()
    for (i in 0 until arr.length()) {
        val x = arr.getJSONObject(i)
        val fixture = x.getJSONObject("fixture")
        val league = x.getJSONObject("league")
        val teams = x.getJSONObject("teams")
        val goals = x.getJSONObject("goals")
        val status = fixture.getJSONObject("status")
        val home = teams.getJSONObject("home")
        val away = teams.getJSONObject("away")
        out += LiveMatch(
            id = fixture.getInt("id"),
            league = league.optString("name", "Diğer"),
            country = league.optString("country", ""),
            homeId = home.optInt("id", 0),
            awayId = away.optInt("id", 0),
            home = home.optString("name", "Ev Sahibi"),
            away = away.optString("name", "Deplasman"),
            homeGoals = if (goals.isNull("home")) null else goals.optInt("home"),
            awayGoals = if (goals.isNull("away")) null else goals.optInt("away"),
            minute = status.optInt("elapsed", 0),
            status = status.optString("short", "LIVE"),
            events = parseEvents(x)
        )
    }
    return LiveResult(out, r.quota)
}

private fun jsonValueToString(value: Any?): String? {
    if (value == null || value == JSONObject.NULL) return null
    return when (value) {
        is Double -> if (value % 1.0 == 0.0) value.toInt().toString() else String.format(Locale.US, "%.2f", value)
        is Float -> String.format(Locale.US, "%.2f", value)
        else -> value.toString()
    }
}

private fun parseStatsBlock(block: JSONObject): TeamStats {
    val team = block.optJSONObject("team") ?: JSONObject()
    val stats = block.optJSONArray("statistics") ?: JSONArray()
    val values = linkedMapOf<String, String?>()
    for (i in 0 until stats.length()) {
        val s = stats.optJSONObject(i) ?: continue
        val type = s.optString("type", "İstatistik")
        values[type] = jsonValueToString(s.opt("value"))
    }
    return TeamStats(
        teamId = team.optInt("id", 0),
        teamName = team.optString("name", "Takım"),
        values = values
    )
}

private fun parseEvents(x: JSONObject): List<MatchEvent> {
    val arr = x.optJSONArray("events") ?: JSONArray()
    val out = mutableListOf<MatchEvent>()
    for (i in 0 until arr.length()) {
        val e = arr.optJSONObject(i) ?: continue
        val time = e.optJSONObject("time")
        val team = e.optJSONObject("team")
        val player = e.optJSONObject("player")
        out += MatchEvent(
            minute = time?.optInt("elapsed", 0) ?: 0,
            team = team?.optString("name", "") ?: "",
            player = player?.optString("name", "") ?: "",
            type = e.optString("type", ""),
            detail = e.optString("detail", "")
        )
    }
    return out
}

private fun normalizeType(type: String): String = type
    .lowercase(Locale.ROOT)
    .replace(Regex("[^a-z0-9]"), "")

private fun statValue(stats: TeamStats?, vararg names: String): String? {
    if (stats == null) return null
    val wanted = names.map(::normalizeType).toSet()
    return stats.values.entries.firstOrNull { normalizeType(it.key) in wanted }?.value
}

private fun statNumber(stats: TeamStats?, vararg names: String): Double {
    val raw = statValue(stats, *names) ?: return 0.0
    return raw.replace("%", "").replace(",", ".").trim().toDoubleOrNull() ?: 0.0
}

private fun pressureScore(stats: TeamStats?, opponent: TeamStats?, minute: Int): Int {
    if (stats == null || stats.values.isEmpty()) return 0
    val m = max(10, minute)
    val pace15 = 15.0 / m.toDouble()
    val shotsOn = statNumber(stats, "Shots on Goal", "Shots on Target")
    val totalShots = statNumber(stats, "Total Shots")
    val inside = statNumber(stats, "Shots insidebox", "Shots inside box")
    val blocked = statNumber(stats, "Blocked Shots")
    val corners = statNumber(stats, "Corner Kicks", "Corners")
    val possession = statNumber(stats, "Ball Possession")
    val xg = statNumber(stats, "expected_goals", "Expected Goals", "xG")
    val opponentRed = statNumber(opponent, "Red Cards")

    var score = 0.0
    score += min(42.0, shotsOn * pace15 * 22.0)
    score += min(20.0, totalShots * pace15 * 4.0)
    score += min(14.0, inside * pace15 * 6.0)
    score += min(12.0, corners * pace15 * 7.0)
    score += min(6.0, blocked * pace15 * 2.0)
    score += min(7.0, max(0.0, possession - 50.0) * 0.35)
    score += min(16.0, xg * pace15 * 20.0)
    if (opponentRed > 0) score += 6.0
    return score.roundToInt().coerceIn(0, 100)
}

private fun buildSignal(match: LiveMatch, home: TeamStats?, away: TeamStats?): GoalSignal? {
    if ((home == null || home.values.isEmpty()) && (away == null || away.values.isEmpty())) return null
    val hp = pressureScore(home, away, match.minute)
    val ap = pressureScore(away, home, match.minute)
    val high = max(hp, ap)
    val low = min(hp, ap)
    var total = (high * 0.78 + low * 0.22).roundToInt()

    val homeSot = statNumber(home, "Shots on Goal", "Shots on Target")
    val awaySot = statNumber(away, "Shots on Goal", "Shots on Target")
    val totalXg = statNumber(home, "expected_goals", "Expected Goals", "xG") +
        statNumber(away, "expected_goals", "Expected Goals", "xG")
    val goalDiff = abs((match.homeGoals ?: 0) - (match.awayGoals ?: 0))
    if (homeSot >= 2 && awaySot >= 2) total += 5
    if (totalXg >= 1.5) total += 6
    if (match.minute >= 60 && goalDiff == 0) total += 4
    if (match.minute >= 75 && goalDiff <= 1) total += 3
    total = total.coerceIn(0, 100)

    val label = when {
        total >= 82 -> "ÇOK YÜKSEK"
        total >= 70 -> "YÜKSEK"
        total >= 55 -> "ORTA"
        else -> "DÜŞÜK"
    }
    val leader = when {
        hp > ap + 5 -> match.home
        ap > hp + 5 -> match.away
        else -> "Dengeli"
    }

    val leadStats = if (hp >= ap) home else away
    val reasons = mutableListOf<String>()
    val sot = statNumber(leadStats, "Shots on Goal", "Shots on Target")
    val corners = statNumber(leadStats, "Corner Kicks", "Corners")
    val xg = statNumber(leadStats, "expected_goals", "Expected Goals", "xG")
    val poss = statNumber(leadStats, "Ball Possession")
    if (sot >= 3) reasons += "Kaleyi bulan şut üretimi güçlü"
    if (corners >= 4) reasons += "Korner baskısı yüksek"
    if (xg >= 1.0) reasons += "Beklenen gol (xG) seviyesi güçlü"
    if (poss >= 58) reasons += "Topa sahip olma üstünlüğü var"
    if (homeSot >= 2 && awaySot >= 2) reasons += "İki takım da kaleyi tehdit ediyor"
    if (reasons.isEmpty()) reasons += "Mevcut maç temposu ve istatistik dengesi değerlendirildi"

    return GoalSignal(total, label, leader, hp, ap, reasons.take(3))
}

private fun parseMatchDetail(x: JSONObject, match: LiveMatch): MatchDetail {
    val statsArray = x.optJSONArray("statistics") ?: JSONArray()
    var homeStats: TeamStats? = null
    var awayStats: TeamStats? = null
    for (i in 0 until statsArray.length()) {
        val block = statsArray.optJSONObject(i) ?: continue
        val parsed = parseStatsBlock(block)
        when (parsed.teamId) {
            match.homeId -> homeStats = parsed
            match.awayId -> awayStats = parsed
            else -> if (homeStats == null) homeStats = parsed else if (awayStats == null) awayStats = parsed
        }
    }
    val events = parseEvents(x)
    return MatchDetail(
        homeStats = homeStats,
        awayStats = awayStats,
        events = events,
        signal = buildSignal(match, homeStats, awayStats),
        updatedAt = System.currentTimeMillis(),
        statsAvailable = homeStats != null || awayStats != null
    )
}

private fun parseStatisticsDetail(root: JSONObject, match: LiveMatch): MatchDetail {
    val statsArray = root.optJSONArray("response") ?: JSONArray()
    var homeStats: TeamStats? = null
    var awayStats: TeamStats? = null
    for (i in 0 until statsArray.length()) {
        val block = statsArray.optJSONObject(i) ?: continue
        val parsed = parseStatsBlock(block)
        when (parsed.teamId) {
            match.homeId -> homeStats = parsed
            match.awayId -> awayStats = parsed
            else -> if (homeStats == null) homeStats = parsed else if (awayStats == null) awayStats = parsed
        }
    }
    return MatchDetail(
        homeStats = homeStats,
        awayStats = awayStats,
        events = match.events,
        signal = buildSignal(match, homeStats, awayStats),
        updatedAt = System.currentTimeMillis(),
        statsAvailable = homeStats != null || awayStats != null
    )
}

private fun fetchDetails(apiKey: String, matches: List<LiveMatch>, knownRemaining: Int?): DetailResult {
    if (matches.isEmpty()) return DetailResult(emptyMap(), ApiQuota(knownRemaining, null), 0)
    val out = linkedMapOf<Int, MatchDetail>()
    var remaining = knownRemaining
    var limit: Int? = null
    var covered = 0

    // Free API-Football plans do not support the multi-fixture `ids` parameter.
    // Fetch each live fixture through the supported statistics endpoint instead.
    for (match in matches) {
        if (remaining != null && remaining <= 8) break
        try {
            val r = requestJson(
                "https://v3.football.api-sports.io/fixtures/statistics?fixture=${match.id}",
                apiKey
            )
            remaining = r.quota.remaining ?: remaining
            limit = r.quota.limit ?: limit
            val detail = parseStatisticsDetail(r.root, match)
            out[match.id] = detail
            if (detail.homeStats != null || detail.awayStats != null) covered++
        } catch (_: Exception) {
            // Some competitions may not expose live statistics. Keep the match visible
            // and continue with the remaining fixtures instead of failing the whole scan.
        }
    }
    return DetailResult(out, ApiQuota(remaining, limit), covered)
}

private fun signalColor(signal: GoalSignal?): Color = when {
    signal == null -> Color.Gray
    signal.score >= 82 -> Red
    signal.score >= 70 -> Orange
    signal.score >= 55 -> Gold
    else -> Green
}

private val preferredStatOrder = listOf(
    "expectedgoals", "shotsongoal", "shotsoffgoal", "totalshots", "blockedshots",
    "shotsinsidebox", "shotsoutsidebox", "cornerkicks", "ballpossession", "goalkeepersaves",
    "fouls", "offsides", "yellowcards", "redcards", "totalpasses", "passesaccurate", "passes"
)

private fun orderedStats(detail: MatchDetail): List<String> {
    val all = linkedSetOf<String>()
    detail.homeStats?.values?.keys?.let(all::addAll)
    detail.awayStats?.values?.keys?.let(all::addAll)
    return all.sortedWith(compareBy<String> {
        val idx = preferredStatOrder.indexOf(normalizeType(it))
        if (idx == -1) 999 else idx
    }.thenBy { it })
}

private fun displayGoal(v: Int?): String = v?.toString() ?: "-"

private val PremiumBgTop = Color(0xFF070B10)
private val PremiumBgBottom = Color(0xFF0B1118)
private val PremiumPanel = Color(0xFF111821)
private val PremiumPanel2 = Color(0xFF0D141C)
private val PremiumStroke = Color(0xFF28323E)
private val PremiumText = Color(0xFFF6F7F9)
private val PremiumMuted = Color(0xFF8C98A6)
private val PremiumGold = Color(0xFFE2B64D)
private val PremiumGoldSoft = Color(0xFFFFD978)
private val PremiumGreen = Color(0xFF5DDB98)
private val PremiumOrange = Color(0xFFFFB456)
private val PremiumRed = Color(0xFFFF6B6B)
private val PremiumPurple = Color(0xFF8C6CF3)

@Composable
private fun StatusPill(text: String, color: Color, subtle: Boolean = true) {
    Box(
        modifier = Modifier
            .background(
                if (subtle) color.copy(alpha = 0.14f) else color,
                RoundedCornerShape(999.dp)
            )
            .padding(horizontal = 10.dp, vertical = 5.dp)
    ) {
        Text(
            text = text,
            color = if (subtle) color else Color.Black,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
private fun MetricTile(label: String, value: String, accent: Color, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = PremiumPanel2),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, PremiumStroke)
    ) {
        Column(Modifier.padding(horizontal = 12.dp, vertical = 12.dp)) {
            Text(value, color = accent, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
            Spacer(Modifier.height(2.dp))
            Text(label, color = PremiumMuted, fontSize = 10.sp)
        }
    }
}

@Composable
private fun MiniStat(label: String, value: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .background(PremiumPanel2, RoundedCornerShape(12.dp))
            .padding(horizontal = 10.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(value, color = PremiumText, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        Text(label, color = PremiumMuted, fontSize = 9.sp)
    }
}

@Composable
private fun SignalBar(score: Int, color: Color, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .height(7.dp)
            .background(Color.White.copy(alpha = 0.08f), RoundedCornerShape(99.dp))
    ) {
        Box(
            modifier = Modifier
                .fillMaxHeight()
                .fillMaxWidth((score.coerceIn(0, 100)) / 100f)
                .background(
                    Brush.horizontalGradient(listOf(color.copy(alpha = 0.72f), color)),
                    RoundedCornerShape(99.dp)
                )
        )
    }
}

@Composable
private fun TeamScoreRow(name: String, score: Int?, highlighted: Boolean) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .background(if (highlighted) PremiumGold else PremiumStroke, RoundedCornerShape(99.dp))
        )
        Spacer(Modifier.width(9.dp))
        Text(
            text = name,
            color = PremiumText,
            fontWeight = if (highlighted) FontWeight.Bold else FontWeight.SemiBold,
            fontSize = 15.sp,
            modifier = Modifier.weight(1f)
        )
        Box(
            modifier = Modifier
                .background(Color.White.copy(alpha = 0.06f), RoundedCornerShape(10.dp))
                .padding(horizontal = 12.dp, vertical = 6.dp)
        ) {
            Text(displayGoal(score), color = PremiumText, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
        }
    }
}

@Composable
private fun StatRow(label: String, home: String?, away: String?) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color.White.copy(alpha = 0.025f), RoundedCornerShape(10.dp))
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            home ?: "—",
            color = PremiumText,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Start,
            modifier = Modifier.weight(0.22f)
        )
        Text(
            label,
            color = PremiumMuted,
            fontSize = 11.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.weight(0.56f)
        )
        Text(
            away ?: "—",
            color = PremiumText,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.End,
            modifier = Modifier.weight(0.22f)
        )
    }
}

@Composable
private fun MatchCard(
    match: LiveMatch,
    detail: MatchDetail?,
    expanded: Boolean,
    onToggle: () -> Unit
) {
    val signal = detail?.signal
    val sigColor = signalColor(signal)
    val homeLeading = (match.homeGoals ?: 0) > (match.awayGoals ?: 0)
    val awayLeading = (match.awayGoals ?: 0) > (match.homeGoals ?: 0)

    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onToggle),
        colors = CardDefaults.cardColors(containerColor = PremiumPanel),
        shape = RoundedCornerShape(22.dp),
        border = BorderStroke(1.dp, if ((signal?.score ?: 0) >= 70) sigColor.copy(alpha = 0.55f) else PremiumStroke)
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(7.dp), verticalAlignment = Alignment.CenterVertically) {
                    StatusPill("● CANLI", PremiumGreen)
                    if (detail != null && detail.statsAvailable) StatusPill("VERİ AKTİF", PremiumPurple)
                }
                Text(
                    if (match.minute > 0) "${match.minute}'" else match.status,
                    color = PremiumGoldSoft,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 16.sp
                )
            }

            Spacer(Modifier.height(15.dp))
            TeamScoreRow(match.home, match.homeGoals, homeLeading)
            Spacer(Modifier.height(8.dp))
            TeamScoreRow(match.away, match.awayGoals, awayLeading)

            Spacer(Modifier.height(14.dp))
            if (signal != null) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = sigColor.copy(alpha = 0.08f)),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, sigColor.copy(alpha = 0.24f))
                ) {
                    Column(Modifier.padding(12.dp)) {
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("GOAL-X GOL SİNYALİ", color = PremiumMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                Text("${signal.score}/100", color = sigColor, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
                            }
                            StatusPill(signal.label, sigColor)
                        }
                        SignalBar(signal.score, sigColor, Modifier.fillMaxWidth())
                        Spacer(Modifier.height(7.dp))
                        Text("Baskı yönü: ${signal.leader}", color = PremiumText, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            } else {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.White.copy(alpha = 0.035f), RoundedCornerShape(14.dp))
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        if (detail != null && !detail.statsAvailable) "Ayrıntılı canlı istatistik bu maç için sunulmuyor"
                        else "Sinyal için canlı istatistik bekleniyor",
                        color = PremiumMuted,
                        fontSize = 11.sp,
                        modifier = Modifier.weight(1f)
                    )
                    StatusPill("BEKLEMEDE", PremiumMuted)
                }
            }

            detail?.let {
                val hs = it.homeStats
                val as_ = it.awayStats
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    MiniStat("ŞUT", "${statValue(hs, "Total Shots") ?: "—"}-${statValue(as_, "Total Shots") ?: "—"}", Modifier.weight(1f))
                    MiniStat("İSABET", "${statValue(hs, "Shots on Goal", "Shots on Target") ?: "—"}-${statValue(as_, "Shots on Goal", "Shots on Target") ?: "—"}", Modifier.weight(1f))
                    MiniStat("KORNER", "${statValue(hs, "Corner Kicks", "Corners") ?: "—"}-${statValue(as_, "Corner Kicks", "Corners") ?: "—"}", Modifier.weight(1f))
                }
            }

            Spacer(Modifier.height(12.dp))
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Maç #${match.id}", color = PremiumMuted, fontSize = 10.sp)
                Text(
                    if (expanded) "AYRINTILARI KAPAT  ▲" else "MAÇ DETAYI  ▼",
                    color = PremiumGold,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            if (expanded) {
                Spacer(Modifier.height(15.dp))
                HorizontalDivider(color = PremiumStroke)
                Spacer(Modifier.height(15.dp))

                if (signal != null) {
                    Text("GOL BASKISI ANALİZİ", color = PremiumGold, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp)
                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        MetricTile(match.home, "${signal.homePressure}/100", if (signal.homePressure >= signal.awayPressure) sigColor else PremiumMuted, Modifier.weight(1f))
                        MetricTile(match.away, "${signal.awayPressure}/100", if (signal.awayPressure > signal.homePressure) sigColor else PremiumMuted, Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(10.dp))
                    signal.reasons.forEach { reason ->
                        Text("• $reason", color = PremiumMuted, fontSize = 11.sp, modifier = Modifier.padding(vertical = 2.dp))
                    }
                    Text(
                        "GOAL-X skoru gol olasılığı veya garanti değildir; canlı istatistiklerden üretilen baskı endeksidir.",
                        color = PremiumMuted.copy(alpha = 0.78f),
                        fontSize = 10.sp,
                        modifier = Modifier.padding(top = 7.dp)
                    )
                    Spacer(Modifier.height(16.dp))
                }

                if (detail == null) {
                    Text("İstatistik taraması henüz yapılmadı.", color = PremiumMuted, fontSize = 12.sp)
                } else if (!detail.statsAvailable) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = PremiumOrange.copy(alpha = 0.07f)),
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, PremiumOrange.copy(alpha = 0.20f))
                    ) {
                        Text(
                            "Bu karşılaşma için sağlayıcı ayrıntılı canlı istatistik sunmuyor. Eksik veriler 0 olarak gösterilmez ve API kotasını korumak için gereksiz tekrar sorgusu yapılmaz.",
                            color = PremiumMuted,
                            fontSize = 11.sp,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                } else {
                    Text("MAÇ İSTATİSTİKLERİ", color = PremiumGold, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp)
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth()) {
                        Text(match.home, color = PremiumText, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.25f))
                        Text("KARŞILAŞTIRMA", color = PremiumMuted, fontSize = 9.sp, textAlign = TextAlign.Center, modifier = Modifier.weight(0.50f))
                        Text(match.away, color = PremiumText, fontSize = 10.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.End, modifier = Modifier.weight(0.25f))
                    }
                    Spacer(Modifier.height(6.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        orderedStats(detail).forEach { type ->
                            StatRow(type, detail.homeStats?.values?.get(type), detail.awayStats?.values?.get(type))
                        }
                    }
                }

                if (!detail?.events.isNullOrEmpty()) {
                    Spacer(Modifier.height(16.dp))
                    Text("CANLI OLAY AKIŞI", color = PremiumGold, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp)
                    Spacer(Modifier.height(8.dp))
                    detail!!.events.takeLast(8).reversed().forEach { e ->
                        val who = listOf(e.team, e.player).filter { it.isNotBlank() }.joinToString(" • ")
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 5.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Text("${e.minute}'", color = PremiumGoldSoft, fontWeight = FontWeight.Bold, fontSize = 11.sp, modifier = Modifier.width(38.dp))
                            Column(Modifier.weight(1f)) {
                                Text("${e.type} • ${e.detail}", color = PremiumText, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                                if (who.isNotBlank()) Text(who, color = PremiumMuted, fontSize = 10.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun LeagueHeader(title: String, count: Int) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(PremiumPanel2, RoundedCornerShape(15.dp))
            .padding(horizontal = 14.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.width(4.dp).height(28.dp).background(PremiumGold, RoundedCornerShape(99.dp)))
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = PremiumText, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold)
            Text("Canlı karşılaşmalar", color = PremiumMuted, fontSize = 9.sp)
        }
        StatusPill("$count MAÇ", PremiumGold)
    }
}

@Composable
fun App() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("goalx", 0) }
    var key by remember { mutableStateOf(prefs.getString("apiKey", "") ?: "") }
    var editing by remember { mutableStateOf(key.isBlank()) }
    var matches by remember { mutableStateOf<List<LiveMatch>>(emptyList()) }
    val details = remember { mutableStateMapOf<Int, MatchDetail>() }
    val statsRetryAfter = remember { mutableStateMapOf<Int, Long>() }
    var loadingLive by remember { mutableStateOf(false) }
    var loadingStats by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var liveRefreshToken by remember { mutableIntStateOf(0) }
    var statsRefreshToken by remember { mutableIntStateOf(0) }
    var quotaRemaining by remember { mutableStateOf<Int?>(null) }
    var quotaLimit by remember { mutableStateOf<Int?>(null) }
    var lastStatsAt by remember { mutableLongStateOf(0L) }
    var expandedId by remember { mutableStateOf<Int?>(null) }
    var signalsOnly by remember { mutableStateOf(false) }

    LaunchedEffect(key, editing, liveRefreshToken) {
        if (key.isBlank() || editing) return@LaunchedEffect
        while (true) {
            loadingLive = true
            error = null
            try {
                val live = withContext(Dispatchers.IO) { fetchLive(key) }
                matches = live.matches
                quotaRemaining = live.quota.remaining ?: quotaRemaining
                quotaLimit = live.quota.limit ?: quotaLimit
                val liveIds = live.matches.map { it.id }.toSet()
                details.keys.toList().filterNot { it in liveIds }.forEach { details.remove(it) }

                val shouldRefreshStats = details.isEmpty() || System.currentTimeMillis() - lastStatsAt >= STATS_REFRESH_MS
                val enoughQuota = (quotaRemaining ?: 100) > 20
                if (shouldRefreshStats && enoughQuota && live.matches.isNotEmpty()) {
                    val now = System.currentTimeMillis()
                    val targets = live.matches.filter { now >= (statsRetryAfter[it.id] ?: 0L) }
                    if (targets.isNotEmpty()) {
                        loadingStats = true
                        val rich = withContext(Dispatchers.IO) { fetchDetails(key, targets, quotaRemaining) }
                        details.putAll(rich.details)
                        rich.details.forEach { (id, detail) ->
                            if (detail.statsAvailable) statsRetryAfter.remove(id)
                            else statsRetryAfter[id] = now + EMPTY_STATS_RETRY_MS
                        }
                        quotaRemaining = rich.quota.remaining ?: quotaRemaining
                        quotaLimit = rich.quota.limit ?: quotaLimit
                        lastStatsAt = System.currentTimeMillis()
                        loadingStats = false
                    }
                }
            } catch (e: Exception) {
                error = e.message ?: "Bağlantı hatası"
            } finally {
                loadingLive = false
                loadingStats = false
            }
            val remaining = quotaRemaining ?: 100
            val wait = when {
                remaining <= 5 -> 900_000L
                remaining <= 20 -> 600_000L
                else -> LIVE_REFRESH_MS
            }
            delay(wait)
        }
    }

    LaunchedEffect(statsRefreshToken) {
        if (statsRefreshToken <= 0 || key.isBlank() || editing || matches.isEmpty() || loadingStats) return@LaunchedEffect
        loadingStats = true
        error = null
        try {
            val now = System.currentTimeMillis()
            val targets = matches.filter { now >= (statsRetryAfter[it.id] ?: 0L) }
            if (targets.isNotEmpty()) {
                val rich = withContext(Dispatchers.IO) { fetchDetails(key, targets, quotaRemaining) }
                details.putAll(rich.details)
                rich.details.forEach { (id, detail) ->
                    if (detail.statsAvailable) statsRetryAfter.remove(id)
                    else statsRetryAfter[id] = now + EMPTY_STATS_RETRY_MS
                }
                quotaRemaining = rich.quota.remaining ?: quotaRemaining
                quotaLimit = rich.quota.limit ?: quotaLimit
                lastStatsAt = System.currentTimeMillis()
            }
        } catch (e: Exception) {
            error = e.message ?: "İstatistik verisi alınamadı"
        } finally {
            loadingStats = false
        }
    }

    val shownMatches = if (signalsOnly) {
        matches.filter { (details[it.id]?.signal?.score ?: 0) >= 70 }
    } else matches
    val highSignalCount = matches.count { (details[it.id]?.signal?.score ?: 0) >= 70 }
    val statsCount = details.values.count { it.statsAvailable }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = PremiumGold,
            secondary = PremiumPurple,
            background = PremiumBgTop,
            surface = PremiumPanel,
            onPrimary = Color.Black,
            onBackground = PremiumText,
            onSurface = PremiumText
        )
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(PremiumBgTop, PremiumBgBottom)))
        ) {
            LazyColumn(
                Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 18.dp, bottom = 30.dp),
                verticalArrangement = Arrangement.spacedBy(13.dp)
            ) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = PremiumPanel.copy(alpha = 0.92f)),
                        shape = RoundedCornerShape(24.dp),
                        border = BorderStroke(1.dp, PremiumStroke)
                    ) {
                        Row(
                            Modifier.fillMaxWidth().padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("GOAL-X", color = PremiumGold, fontSize = 27.sp, fontWeight = FontWeight.Black)
                                    Text(" AI", color = PremiumText, fontSize = 27.sp, fontWeight = FontWeight.Black)
                                }
                                Spacer(Modifier.height(3.dp))
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                                    StatusPill("LIVE", PremiumGreen)
                                    Text("V2.4 PREMIUM SIGNAL", color = PremiumMuted, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                                }
                            }
                            OutlinedButton(
                                onClick = { editing = true },
                                shape = RoundedCornerShape(14.dp),
                                border = BorderStroke(1.dp, PremiumGold.copy(alpha = 0.45f)),
                                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 9.dp)
                            ) {
                                Text("API", color = PremiumGold, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                if (editing) item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = PremiumPanel),
                        shape = RoundedCornerShape(22.dp),
                        border = BorderStroke(1.dp, PremiumStroke)
                    ) {
                        Column(Modifier.padding(17.dp)) {
                            Text("API BAĞLANTISI", color = PremiumGold, fontWeight = FontWeight.ExtraBold, fontSize = 12.sp)
                            Spacer(Modifier.height(4.dp))
                            Text("Canlı futbol verilerini bağla", color = PremiumText, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            Spacer(Modifier.height(12.dp))
                            OutlinedTextField(
                                value = key,
                                onValueChange = { key = it },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                label = { Text("API-Sports / API-Football key") },
                                shape = RoundedCornerShape(14.dp)
                            )
                            Spacer(Modifier.height(10.dp))
                            Button(
                                onClick = {
                                    val clean = key.trim()
                                    prefs.edit().putString("apiKey", clean).apply()
                                    key = clean
                                    editing = false
                                    liveRefreshToken++
                                },
                                modifier = Modifier.fillMaxWidth().height(50.dp),
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = PremiumGold, contentColor = Color.Black)
                            ) {
                                Text("BAĞLAN VE CANLI MAÇLARI GETİR", fontWeight = FontWeight.ExtraBold)
                            }
                            Spacer(Modifier.height(8.dp))
                            Text("API anahtarı yalnızca bu cihazda saklanır; GitHub projesine yazılmaz.", color = PremiumMuted, fontSize = 10.sp)
                        }
                    }
                }

                if (key.isNotBlank() && !editing) item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = PremiumPanel),
                        shape = RoundedCornerShape(22.dp),
                        border = BorderStroke(1.dp, PremiumStroke)
                    ) {
                        Column(Modifier.padding(15.dp)) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                MetricTile("CANLI MAÇ", matches.size.toString(), PremiumGold, Modifier.weight(1f))
                                MetricTile("YÜKSEK SİNYAL", highSignalCount.toString(), if (highSignalCount > 0) PremiumRed else PremiumMuted, Modifier.weight(1f))
                                MetricTile("İSTATİSTİKLİ", statsCount.toString(), PremiumGreen, Modifier.weight(1f))
                            }
                            Spacer(Modifier.height(10.dp))
                            Row(
                                Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("API kullanım durumu", color = PremiumMuted, fontSize = 10.sp)
                                StatusPill(
                                    if (quotaRemaining != null) "${quotaRemaining}${quotaLimit?.let { "/$it" } ?: ""}" else "—",
                                    if ((quotaRemaining ?: 100) <= 20) PremiumOrange else PremiumGreen
                                )
                            }
                            Spacer(Modifier.height(9.dp))
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = { liveRefreshToken++ },
                                    enabled = !loadingLive,
                                    modifier = Modifier.weight(1f).height(46.dp),
                                    shape = RoundedCornerShape(14.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = PremiumGold, contentColor = Color.Black)
                                ) { Text("CANLIYI YENİLE", fontSize = 10.sp, fontWeight = FontWeight.ExtraBold) }
                                OutlinedButton(
                                    onClick = { statsRefreshToken++ },
                                    enabled = !loadingStats && matches.isNotEmpty() && (quotaRemaining ?: 100) > 5,
                                    modifier = Modifier.weight(1f).height(46.dp),
                                    shape = RoundedCornerShape(14.dp),
                                    border = BorderStroke(1.dp, PremiumPurple.copy(alpha = 0.55f))
                                ) { Text("SİNYALLERİ TARA", color = PremiumPurple, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold) }
                            }
                            Spacer(Modifier.height(9.dp))
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                FilterChip(
                                    selected = !signalsOnly,
                                    onClick = { signalsOnly = false },
                                    label = { Text("TÜM MAÇLAR", fontSize = 10.sp) }
                                )
                                FilterChip(
                                    selected = signalsOnly,
                                    onClick = { signalsOnly = true },
                                    label = { Text("70+ YÜKSEK SİNYAL", fontSize = 10.sp) }
                                )
                            }
                            Spacer(Modifier.height(7.dp))
                            Text(
                                "Canlı skor yaklaşık 5 dk aralıkla yenilenir. Veri vermeyen maçlar API kotasını korumak için 2 saat tekrar taranmaz.",
                                color = PremiumMuted,
                                fontSize = 9.sp
                            )
                        }
                    }
                }

                if (loadingLive) item {
                    Column {
                        Text("Canlı maçlar güncelleniyor…", color = PremiumMuted, fontSize = 10.sp)
                        Spacer(Modifier.height(5.dp))
                        LinearProgressIndicator(Modifier.fillMaxWidth(), color = PremiumGold, trackColor = PremiumStroke)
                    }
                }
                if (loadingStats) item {
                    Column {
                        Text("Canlı istatistikler taranıyor ve GOAL-X sinyalleri hesaplanıyor…", color = PremiumGold, fontSize = 10.sp)
                        Spacer(Modifier.height(5.dp))
                        LinearProgressIndicator(Modifier.fillMaxWidth(), color = PremiumPurple, trackColor = PremiumStroke)
                    }
                }

                error?.let { e ->
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = PremiumRed.copy(alpha = 0.09f)),
                            shape = RoundedCornerShape(18.dp),
                            border = BorderStroke(1.dp, PremiumRed.copy(alpha = 0.25f))
                        ) {
                            Column(Modifier.padding(15.dp)) {
                                Text("VERİ BAĞLANTISI KESİLDİ", color = PremiumRed, fontWeight = FontWeight.ExtraBold, fontSize = 11.sp)
                                Spacer(Modifier.height(4.dp))
                                Text(e, color = PremiumMuted, fontSize = 11.sp)
                                TextButton(onClick = { liveRefreshToken++ }) { Text("TEKRAR DENE", color = PremiumGold) }
                            }
                        }
                    }
                }

                if (!loadingLive && error == null && key.isNotBlank() && matches.isEmpty()) {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = PremiumPanel2),
                            shape = RoundedCornerShape(18.dp),
                            border = BorderStroke(1.dp, PremiumStroke)
                        ) {
                            Text("Şu anda API'de canlı karşılaşma görünmüyor.", color = PremiumMuted, modifier = Modifier.padding(16.dp))
                        }
                    }
                }

                if (signalsOnly && matches.isNotEmpty() && shownMatches.isEmpty()) {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = PremiumPanel2),
                            shape = RoundedCornerShape(18.dp),
                            border = BorderStroke(1.dp, PremiumStroke)
                        ) {
                            Text("Şu anda 70+ GOAL-X sinyali yok. Yeni istatistikler geldikçe bu alan otomatik güncellenecek.", color = PremiumMuted, fontSize = 11.sp, modifier = Modifier.padding(16.dp))
                        }
                    }
                }

                shownMatches.groupBy { "${it.country} • ${it.league}" }.forEach { (league, leagueMatches) ->
                    item { LeagueHeader(league, leagueMatches.size) }
                    items(leagueMatches, key = { it.id }) { m ->
                        MatchCard(
                            match = m,
                            detail = details[m.id],
                            expanded = expandedId == m.id,
                            onToggle = { expandedId = if (expandedId == m.id) null else m.id }
                        )
                    }
                }

                if (matches.isNotEmpty()) item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = PremiumPanel2),
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.dp, PremiumStroke)
                    ) {
                        Text(
                            "GOAL-X sinyali; sağlayıcının sunduğu şut, isabetli şut, ceza sahası içi şut, korner, topa sahip olma, xG ve kart verilerinden hesaplanan canlı baskı endeksidir. Eksik veri 0 kabul edilmez ve skor gol garantisi değildir.",
                            color = PremiumMuted,
                            fontSize = 9.sp,
                            modifier = Modifier.padding(13.dp)
                        )
                    }
                }
            }
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}
