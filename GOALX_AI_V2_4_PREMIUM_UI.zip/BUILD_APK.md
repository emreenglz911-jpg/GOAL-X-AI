# GOAL-X AI V2.4 PREMIUM SIGNAL

Bu paket, GOAL-X AI uygulamasının premium arayüz sürümüdür.

## Öne çıkanlar
- Premium siyah / altın / koyu lacivert arayüz
- Canlı maç, yüksek sinyal ve istatistikli maç özet kartları
- Lig bazında modern bölüm başlıkları
- Canlı maç kartlarında takım / skor / dakika ayrımı
- GOAL-X sinyal kartı ve görsel sinyal çubuğu
- Maç detayında baskı karşılaştırması
- Geliştirilmiş istatistik tablosu ve canlı olay akışı
- API kotası ve veri durumu göstergeleri

## Derleme
GitHub Actions üzerinden `assembleDebug` ile APK üretilebilir.
