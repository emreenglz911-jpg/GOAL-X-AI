GitHub Actions ile APK oluşturmak için bu projeyi kullan.
Bu proje demo canlı veri içermeyen Android uygulamasıdır.
