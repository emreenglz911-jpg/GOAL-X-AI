package com.goalxai.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.max
import kotlin.math.min

data class Match(
    val home:String,val away:String,val minute:Int,val score:String,
    val shots5:Int,val onTarget5:Int,val dangerousDelta:Double,val xgDelta:Double,val corners:Int
)

fun goalX(m:Match):Int{
    var s=35.0
    s+=min(25.0,m.shots5*4.0)
    s+=min(20.0,m.onTarget5*7.0)
    s+=min(12.0,max(0.0,m.dangerousDelta)*1.2)
    s+=min(15.0,max(0.0,m.xgDelta)*20.0)
    s+=min(5.0,m.corners*1.5)
    if(m.minute>=70)s+=5
    return min(99,max(0,s.toInt()))
}

@Composable
fun App(){
    val matches=listOf(
        Match("Demo FC","United FC",76,"1 - 0",4,2,8.0,.34,3),
        Match("City Blue","Athletic",68,"0 - 0",3,1,5.0,.21,2),
        Match("Red Stars","Green Town",83,"1 - 1",5,3,10.0,.42,4),
        Match("North FC","South FC",61,"0 - 0",1,0,1.0,.05,1)
    )
    MaterialTheme{
        Surface(Modifier.fillMaxSize(),color=Color(0xFF0B0F14)){
            LazyColumn(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
                item{
                    Text("GOAL-X AI",color=Color(0xFFD4AF37),fontSize=30.sp,fontWeight=FontWeight.Bold)
                    Text("Canlı gol baskısı analiz motoru • V1.0",color=Color.LightGray)
                }
                items(matches){m->
                    val s=goalX(m)
                    val label=when{ s>=90->"ÇOK GÜÇLÜ BASKI"; s>=80->"GÜÇLÜ BASKI"; s>=70->"İZLE"; else->"SİNYAL YOK"}
                    Card(colors=CardDefaults.cardColors(containerColor=Color(0xFF151B22)),shape=RoundedCornerShape(18.dp)){
                        Column(Modifier.padding(16.dp)){
                            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){
                                Text("${m.home}  ${m.score}  ${m.away}",color=Color.White,fontWeight=FontWeight.Bold)
                                Text("${m.minute}'",color=Color(0xFFD4AF37))
                            }
                            Spacer(Modifier.height(8.dp))
                            Text("GOAL-X  $s / 100",color=Color.White,fontSize=22.sp,fontWeight=FontWeight.Bold)
                            LinearProgressIndicator(progress={s/100f},Modifier.fillMaxWidth().padding(vertical=8.dp),color=Color(0xFFD4AF37))
                            Text(label,color=Color.White,fontWeight=FontWeight.Bold)
                            Text("Son 5 dk: ${m.shots5} şut • ${m.onTarget5} isabetli",color=Color.Gray)
                            Text("Tehlikeli atak ivmesi: ${m.dangerousDelta}",color=Color.Gray)
                            Text("xG ivmesi: ${m.xgDelta} • Korner: ${m.corners}",color=Color.Gray)
                        }
                    }
                }
                item{Text("Demo sürümü: gerçek canlı veri bağlı değildir. Skor garanti veya bahis sonucu tahmini değildir.",color=Color.Gray,fontSize=12.sp)}
            }
        }
    }
}
class MainActivity:ComponentActivity(){
    override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent{App()}}
}
