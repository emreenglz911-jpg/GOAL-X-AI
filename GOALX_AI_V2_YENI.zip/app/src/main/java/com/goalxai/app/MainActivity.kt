package com.goalxai.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

private val Gold=Color(0xFFD4AF37); private val Bg=Color(0xFF0B0F14); private val CardBg=Color(0xFF151B22)
data class LiveMatch(val id:Int,val league:String,val country:String,val home:String,val away:String,val homeGoals:String,val awayGoals:String,val minute:Int,val status:String)

private fun fetchLive(apiKey:String):List<LiveMatch>{
    val c=(URL("https://v3.football.api-sports.io/fixtures?live=all").openConnection() as HttpURLConnection).apply{
        requestMethod="GET"; setRequestProperty("x-apisports-key",apiKey); connectTimeout=15000; readTimeout=15000
    }
    val code=c.responseCode; val body=(if(code in 200..299)c.inputStream else c.errorStream).bufferedReader().use{it.readText()}
    if(code !in 200..299) error("API hatası ($code)")
    val root=JSONObject(body); val errors=root.optJSONObject("errors")
    if(errors!=null && errors.length()>0) error("API anahtarı/plan kontrol edilmeli")
    val arr=root.getJSONArray("response"); val out=mutableListOf<LiveMatch>()
    for(i in 0 until arr.length()){
        val x=arr.getJSONObject(i); val f=x.getJSONObject("fixture"); val l=x.getJSONObject("league"); val t=x.getJSONObject("teams"); val g=x.getJSONObject("goals"); val st=f.getJSONObject("status")
        out+=LiveMatch(f.getInt("id"),l.optString("name","Diğer"),l.optString("country",""),t.getJSONObject("home").optString("name"),t.getJSONObject("away").optString("name"),if(g.isNull("home"))"-" else g.optInt("home").toString(),if(g.isNull("away"))"-" else g.optInt("away").toString(),st.optInt("elapsed",0),st.optString("short","LIVE"))
    }
    return out
}

@Composable fun App(){
    val ctx=androidx.compose.ui.platform.LocalContext.current
    val prefs=remember{ctx.getSharedPreferences("goalx",0)}
    var key by remember{mutableStateOf(prefs.getString("apiKey","")?:"")}; var editing by remember{mutableStateOf(key.isBlank())}
    var matches by remember{mutableStateOf<List<LiveMatch>>(emptyList())}; var loading by remember{mutableStateOf(false)}; var error by remember{mutableStateOf<String?>(null)}; var refresh by remember{mutableIntStateOf(0)}
    LaunchedEffect(key,refresh){ if(key.isNotBlank()&&!editing){ while(true){ loading=true; error=null; try{matches=withContext(Dispatchers.IO){fetchLive(key)}}catch(e:Exception){error=e.message?:"Bağlantı hatası"}; loading=false; delay(30_000) } } }
    MaterialTheme{Surface(Modifier.fillMaxSize(),color=Bg){
        LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
            item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Column{Text("GOAL-X AI",color=Gold,fontSize=30.sp,fontWeight=FontWeight.Bold);Text("LIVE • V2.0",color=Color.LightGray)};TextButton(onClick={editing=true}){Text("API",color=Gold)}}}
            if(editing) item{Card(colors=CardDefaults.cardColors(containerColor=CardBg)){Column(Modifier.padding(16.dp)){Text("Canlı Futbol API Anahtarı",color=Color.White,fontWeight=FontWeight.Bold);Spacer(Modifier.height(8.dp));OutlinedTextField(key,{key=it},Modifier.fillMaxWidth(),singleLine=true,label={Text("API-Sports / API-Football key")});Button(onClick={prefs.edit().putString("apiKey",key.trim()).apply();key=key.trim();editing=false;refresh++},Modifier.fillMaxWidth()){Text("KAYDET VE CANLI MAÇLARI GETİR")};Text("Anahtar yalnızca bu telefonda saklanır. GitHub projesine yazılmaz.",color=Color.Gray,fontSize=12.sp)}}}
            if(loading) item{LinearProgressIndicator(Modifier.fillMaxWidth(),color=Gold)}
            error?.let{e->item{Card(colors=CardDefaults.cardColors(containerColor=Color(0xFF3A1717))){Column(Modifier.padding(16.dp)){Text("Canlı veri alınamadı",color=Color.White,fontWeight=FontWeight.Bold);Text(e,color=Color.LightGray);TextButton(onClick={refresh++}){Text("TEKRAR DENE")}}}}}
            if(!loading&&error==null&&key.isNotBlank()&&matches.isEmpty()) item{Text("Şu anda API'de canlı maç görünmüyor.",color=Color.LightGray)}
            matches.groupBy{"${it.country} • ${it.league}"}.forEach{(league,ms)->
                item{Text(league,color=Gold,fontSize=19.sp,fontWeight=FontWeight.Bold)}
                items(ms,key={it.id}){m->Card(colors=CardDefaults.cardColors(containerColor=CardBg),shape=RoundedCornerShape(18.dp)){Column(Modifier.padding(16.dp)){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("${m.home}  ${m.homeGoals} - ${m.awayGoals}  ${m.away}",color=Color.White,fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f));Text(if(m.minute>0)"${m.minute}'" else m.status,color=Gold)};Spacer(Modifier.height(8.dp));Text("● CANLI",color=Color(0xFF67D391),fontWeight=FontWeight.Bold);Text("Maç #${m.id} • ${m.status}",color=Color.Gray,fontSize=12.sp)}}}
            }
            if(matches.isNotEmpty()) item{OutlinedButton(onClick={refresh++},Modifier.fillMaxWidth()){Text("ŞİMDİ YENİLE")};Text("Canlı liste 30 saniyede bir otomatik yenilenir. GOAL-X baskı puanı sonraki aşamada canlı maç istatistikleriyle hesaplanacaktır.",color=Color.Gray,fontSize=12.sp)}
        }
    }}
}
class MainActivity:ComponentActivity(){override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent{App()}}}
