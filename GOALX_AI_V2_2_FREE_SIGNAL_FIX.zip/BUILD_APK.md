# GOAL-X AI V2.2 PRO SIGNAL

Free-plan uyumluluk düzeltmesi:
- `fixtures?ids=` kaldırıldı.
- Canlı maç istatistikleri `fixtures/statistics?fixture=ID` üzerinden alınır.
- Tüm API tarafından dönen takım istatistikleri gösterilir.
- GOAL-X gol baskı/sinyal skoru bu istatistiklerden hesaplanır.
- Canlı skor yaklaşık 5 dk, istatistik taraması yaklaşık 30 dk yenilenir.
- Kota düşükse otomatik yavaşlar.
- Bazı liglerde istatistik alanları sağlayıcı tarafından sunulmayabilir; eksikler `—` olarak gösterilir.
