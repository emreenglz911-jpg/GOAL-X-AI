package com.goalxai.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

private val Gold = Color(0xFFD4AF37)
private val Bg = Color(0xFF0B0F14)
private val CardBg = Color(0xFF151B22)
private val SoftCard = Color(0xFF10161D)
private val Green = Color(0xFF67D391)
private val Orange = Color(0xFFFFB74D)
private val Red = Color(0xFFFF6B6B)

private const val LIVE_REFRESH_MS = 300_000L
private const val STATS_REFRESH_MS = 1_800_000L

data class LiveMatch(
    val id: Int,
    val league: String,
    val country: String,
    val homeId: Int,
    val awayId: Int,
    val home: String,
    val away: String,
    val homeGoals: Int?,
    val awayGoals: Int?,
    val minute: Int,
    val status: String
)

data class ApiQuota(val remaining: Int?, val limit: Int?)
data class LiveResult(val matches: List<LiveMatch>, val quota: ApiQuota)

data class TeamStats(
    val teamId: Int,
    val teamName: String,
    val values: Map<String, String?>
)

data class MatchEvent(
    val minute: Int,
    val team: String,
    val player: String,
    val type: String,
    val detail: String
)

data class GoalSignal(
    val score: Int,
    val label: String,
    val leader: String,
    val homePressure: Int,
    val awayPressure: Int,
    val reasons: List<String>
)

data class MatchDetail(
    val homeStats: TeamStats?,
    val awayStats: TeamStats?,
    val events: List<MatchEvent>,
    val signal: GoalSignal?,
    val updatedAt: Long
)

data class DetailResult(
    val details: Map<Int, MatchDetail>,
    val quota: ApiQuota,
    val coveredMatches: Int
)

data class ApiJson(val root: JSONObject, val quota: ApiQuota)

private fun requestJson(url: String, apiKey: String): ApiJson {
    val c = (URL(url).openConnection() as HttpURLConnection).apply {
        requestMethod = "GET"
        setRequestProperty("x-apisports-key", apiKey)
        connectTimeout = 15_000
        readTimeout = 15_000
    }
    val code = c.responseCode
    val remaining = c.getHeaderField("x-ratelimit-requests-remaining")?.toIntOrNull()
    val limit = c.getHeaderField("x-ratelimit-requests-limit")?.toIntOrNull()
    val stream = if (code in 200..299) c.inputStream else c.errorStream
    val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
    if (code !in 200..299) error("API hatası ($code)")
    val root = JSONObject(body)
    val errors = root.opt("errors")
    if (errors != null && errors != JSONObject.NULL) {
        val text = errors.toString()
        if (text != "{}" && text != "[]" && text.isNotBlank()) {
            error("API: $text")
        }
    }
    return ApiJson(root, ApiQuota(remaining, limit))
}

private fun fetchLive(apiKey: String): LiveResult {
    val r = requestJson("https://v3.football.api-sports.io/fixtures?live=all", apiKey)
    val arr = r.root.optJSONArray("response") ?: JSONArray()
    val out = mutableListOf<LiveMatch>()
    for (i in 0 until arr.length()) {
        val x = arr.getJSONObject(i)
        val fixture = x.getJSONObject("fixture")
        val league = x.getJSONObject("league")
        val teams = x.getJSONObject("teams")
        val goals = x.getJSONObject("goals")
        val status = fixture.getJSONObject("status")
        val home = teams.getJSONObject("home")
        val away = teams.getJSONObject("away")
        out += LiveMatch(
            id = fixture.getInt("id"),
            league = league.optString("name", "Diğer"),
            country = league.optString("country", ""),
            homeId = home.optInt("id", 0),
            awayId = away.optInt("id", 0),
            home = home.optString("name", "Ev Sahibi"),
            away = away.optString("name", "Deplasman"),
            homeGoals = if (goals.isNull("home")) null else goals.optInt("home"),
            awayGoals = if (goals.isNull("away")) null else goals.optInt("away"),
            minute = status.optInt("elapsed", 0),
            status = status.optString("short", "LIVE")
        )
    }
    return LiveResult(out, r.quota)
}

private fun jsonValueToString(value: Any?): String? {
    if (value == null || value == JSONObject.NULL) return null
    return when (value) {
        is Double -> if (value % 1.0 == 0.0) value.toInt().toString() else String.format(Locale.US, "%.2f", value)
        is Float -> String.format(Locale.US, "%.2f", value)
        else -> value.toString()
    }
}

private fun parseStatsBlock(block: JSONObject): TeamStats {
    val team = block.optJSONObject("team") ?: JSONObject()
    val stats = block.optJSONArray("statistics") ?: JSONArray()
    val values = linkedMapOf<String, String?>()
    for (i in 0 until stats.length()) {
        val s = stats.optJSONObject(i) ?: continue
        val type = s.optString("type", "İstatistik")
        values[type] = jsonValueToString(s.opt("value"))
    }
    return TeamStats(
        teamId = team.optInt("id", 0),
        teamName = team.optString("name", "Takım"),
        values = values
    )
}

private fun parseEvents(x: JSONObject): List<MatchEvent> {
    val arr = x.optJSONArray("events") ?: JSONArray()
    val out = mutableListOf<MatchEvent>()
    for (i in 0 until arr.length()) {
        val e = arr.optJSONObject(i) ?: continue
        val time = e.optJSONObject("time")
        val team = e.optJSONObject("team")
        val player = e.optJSONObject("player")
        out += MatchEvent(
            minute = time?.optInt("elapsed", 0) ?: 0,
            team = team?.optString("name", "") ?: "",
            player = player?.optString("name", "") ?: "",
            type = e.optString("type", ""),
            detail = e.optString("detail", "")
        )
    }
    return out
}

private fun normalizeType(type: String): String = type
    .lowercase(Locale.ROOT)
    .replace(Regex("[^a-z0-9]"), "")

private fun statValue(stats: TeamStats?, vararg names: String): String? {
    if (stats == null) return null
    val wanted = names.map(::normalizeType).toSet()
    return stats.values.entries.firstOrNull { normalizeType(it.key) in wanted }?.value
}

private fun statNumber(stats: TeamStats?, vararg names: String): Double {
    val raw = statValue(stats, *names) ?: return 0.0
    return raw.replace("%", "").replace(",", ".").trim().toDoubleOrNull() ?: 0.0
}

private fun pressureScore(stats: TeamStats?, opponent: TeamStats?, minute: Int): Int {
    if (stats == null || stats.values.isEmpty()) return 0
    val m = max(10, minute)
    val pace15 = 15.0 / m.toDouble()
    val shotsOn = statNumber(stats, "Shots on Goal", "Shots on Target")
    val totalShots = statNumber(stats, "Total Shots")
    val inside = statNumber(stats, "Shots insidebox", "Shots inside box")
    val blocked = statNumber(stats, "Blocked Shots")
    val corners = statNumber(stats, "Corner Kicks", "Corners")
    val possession = statNumber(stats, "Ball Possession")
    val xg = statNumber(stats, "expected_goals", "Expected Goals", "xG")
    val opponentRed = statNumber(opponent, "Red Cards")

    var score = 0.0
    score += min(42.0, shotsOn * pace15 * 22.0)
    score += min(20.0, totalShots * pace15 * 4.0)
    score += min(14.0, inside * pace15 * 6.0)
    score += min(12.0, corners * pace15 * 7.0)
    score += min(6.0, blocked * pace15 * 2.0)
    score += min(7.0, max(0.0, possession - 50.0) * 0.35)
    score += min(16.0, xg * pace15 * 20.0)
    if (opponentRed > 0) score += 6.0
    return score.roundToInt().coerceIn(0, 100)
}

private fun buildSignal(match: LiveMatch, home: TeamStats?, away: TeamStats?): GoalSignal? {
    if ((home == null || home.values.isEmpty()) && (away == null || away.values.isEmpty())) return null
    val hp = pressureScore(home, away, match.minute)
    val ap = pressureScore(away, home, match.minute)
    val high = max(hp, ap)
    val low = min(hp, ap)
    var total = (high * 0.78 + low * 0.22).roundToInt()

    val homeSot = statNumber(home, "Shots on Goal", "Shots on Target")
    val awaySot = statNumber(away, "Shots on Goal", "Shots on Target")
    val totalXg = statNumber(home, "expected_goals", "Expected Goals", "xG") +
        statNumber(away, "expected_goals", "Expected Goals", "xG")
    val goalDiff = abs((match.homeGoals ?: 0) - (match.awayGoals ?: 0))
    if (homeSot >= 2 && awaySot >= 2) total += 5
    if (totalXg >= 1.5) total += 6
    if (match.minute >= 60 && goalDiff == 0) total += 4
    if (match.minute >= 75 && goalDiff <= 1) total += 3
    total = total.coerceIn(0, 100)

    val label = when {
        total >= 82 -> "ÇOK YÜKSEK"
        total >= 70 -> "YÜKSEK"
        total >= 55 -> "ORTA"
        else -> "DÜŞÜK"
    }
    val leader = when {
        hp > ap + 5 -> match.home
        ap > hp + 5 -> match.away
        else -> "Dengeli"
    }

    val leadStats = if (hp >= ap) home else away
    val reasons = mutableListOf<String>()
    val sot = statNumber(leadStats, "Shots on Goal", "Shots on Target")
    val corners = statNumber(leadStats, "Corner Kicks", "Corners")
    val xg = statNumber(leadStats, "expected_goals", "Expected Goals", "xG")
    val poss = statNumber(leadStats, "Ball Possession")
    if (sot >= 3) reasons += "Kaleyi bulan şut üretimi güçlü"
    if (corners >= 4) reasons += "Korner baskısı yüksek"
    if (xg >= 1.0) reasons += "Beklenen gol (xG) seviyesi güçlü"
    if (poss >= 58) reasons += "Topa sahip olma üstünlüğü var"
    if (homeSot >= 2 && awaySot >= 2) reasons += "İki takım da kaleyi tehdit ediyor"
    if (reasons.isEmpty()) reasons += "Mevcut maç temposu ve istatistik dengesi değerlendirildi"

    return GoalSignal(total, label, leader, hp, ap, reasons.take(3))
}

private fun parseMatchDetail(x: JSONObject, match: LiveMatch): MatchDetail {
    val statsArray = x.optJSONArray("statistics") ?: JSONArray()
    var homeStats: TeamStats? = null
    var awayStats: TeamStats? = null
    for (i in 0 until statsArray.length()) {
        val block = statsArray.optJSONObject(i) ?: continue
        val parsed = parseStatsBlock(block)
        when (parsed.teamId) {
            match.homeId -> homeStats = parsed
            match.awayId -> awayStats = parsed
            else -> if (homeStats == null) homeStats = parsed else if (awayStats == null) awayStats = parsed
        }
    }
    val events = parseEvents(x)
    return MatchDetail(
        homeStats = homeStats,
        awayStats = awayStats,
        events = events,
        signal = buildSignal(match, homeStats, awayStats),
        updatedAt = System.currentTimeMillis()
    )
}

private fun parseStatisticsDetail(root: JSONObject, match: LiveMatch): MatchDetail {
    val statsArray = root.optJSONArray("response") ?: JSONArray()
    var homeStats: TeamStats? = null
    var awayStats: TeamStats? = null
    for (i in 0 until statsArray.length()) {
        val block = statsArray.optJSONObject(i) ?: continue
        val parsed = parseStatsBlock(block)
        when (parsed.teamId) {
            match.homeId -> homeStats = parsed
            match.awayId -> awayStats = parsed
            else -> if (homeStats == null) homeStats = parsed else if (awayStats == null) awayStats = parsed
        }
    }
    return MatchDetail(
        homeStats = homeStats,
        awayStats = awayStats,
        events = emptyList(),
        signal = buildSignal(match, homeStats, awayStats),
        updatedAt = System.currentTimeMillis()
    )
}

private fun fetchDetails(apiKey: String, matches: List<LiveMatch>, knownRemaining: Int?): DetailResult {
    if (matches.isEmpty()) return DetailResult(emptyMap(), ApiQuota(knownRemaining, null), 0)
    val out = linkedMapOf<Int, MatchDetail>()
    var remaining = knownRemaining
    var limit: Int? = null
    var covered = 0

    // Free API-Football plans do not support the multi-fixture `ids` parameter.
    // Fetch each live fixture through the supported statistics endpoint instead.
    for (match in matches) {
        if (remaining != null && remaining <= 8) break
        try {
            val r = requestJson(
                "https://v3.football.api-sports.io/fixtures/statistics?fixture=${match.id}",
                apiKey
            )
            remaining = r.quota.remaining ?: remaining
            limit = r.quota.limit ?: limit
            val detail = parseStatisticsDetail(r.root, match)
            out[match.id] = detail
            if (detail.homeStats != null || detail.awayStats != null) covered++
        } catch (_: Exception) {
            // Some competitions may not expose live statistics. Keep the match visible
            // and continue with the remaining fixtures instead of failing the whole scan.
        }
    }
    return DetailResult(out, ApiQuota(remaining, limit), covered)
}

private fun signalColor(signal: GoalSignal?): Color = when {
    signal == null -> Color.Gray
    signal.score >= 82 -> Red
    signal.score >= 70 -> Orange
    signal.score >= 55 -> Gold
    else -> Green
}

private val preferredStatOrder = listOf(
    "expectedgoals", "shotsongoal", "shotsoffgoal", "totalshots", "blockedshots",
    "shotsinsidebox", "shotsoutsidebox", "cornerkicks", "ballpossession", "goalkeepersaves",
    "fouls", "offsides", "yellowcards", "redcards", "totalpasses", "passesaccurate", "passes"
)

private fun orderedStats(detail: MatchDetail): List<String> {
    val all = linkedSetOf<String>()
    detail.homeStats?.values?.keys?.let(all::addAll)
    detail.awayStats?.values?.keys?.let(all::addAll)
    return all.sortedWith(compareBy<String> {
        val idx = preferredStatOrder.indexOf(normalizeType(it))
        if (idx == -1) 999 else idx
    }.thenBy { it })
}

private fun displayGoal(v: Int?): String = v?.toString() ?: "-"

@Composable
private fun StatRow(label: String, home: String?, away: String?) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(home ?: "—", color = Color.White, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(0.24f))
        Text(label, color = Color.LightGray, fontSize = 12.sp, modifier = Modifier.weight(0.52f))
        Text(away ?: "—", color = Color.White, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(0.24f))
    }
}

@Composable
private fun MatchCard(
    match: LiveMatch,
    detail: MatchDetail?,
    expanded: Boolean,
    onToggle: () -> Unit
) {
    val signal = detail?.signal
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onToggle),
        colors = CardDefaults.cardColors(containerColor = CardBg),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(
                    "${match.home}  ${displayGoal(match.homeGoals)} - ${displayGoal(match.awayGoals)}  ${match.away}",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )
                Text(if (match.minute > 0) "${match.minute}'" else match.status, color = Gold)
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("● CANLI", color = Green, fontWeight = FontWeight.Bold)
                if (signal != null) {
                    Text(
                        "GOAL-X ${signal.score}/100 • ${signal.label}",
                        color = signalColor(signal),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                } else {
                    Text("Sinyal verisi bekleniyor", color = Color.Gray, fontSize = 12.sp)
                }
            }
            if (detail != null) {
                val hs = detail.homeStats
                val as_ = detail.awayStats
                Spacer(Modifier.height(8.dp))
                Text(
                    "Şut ${statValue(hs, "Total Shots") ?: "—"}-${statValue(as_, "Total Shots") ?: "—"}  •  " +
                        "İsabet ${statValue(hs, "Shots on Goal", "Shots on Target") ?: "—"}-${statValue(as_, "Shots on Goal", "Shots on Target") ?: "—"}  •  " +
                        "Korner ${statValue(hs, "Corner Kicks", "Corners") ?: "—"}-${statValue(as_, "Corner Kicks", "Corners") ?: "—"}",
                    color = Color.LightGray,
                    fontSize = 12.sp
                )
            }
            Text(if (expanded) "▲ Detayı kapat" else "▼ Tüm istatistikler", color = Gold, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp))

            if (expanded) {
                Spacer(Modifier.height(14.dp))
                HorizontalDivider(color = Color.DarkGray)
                Spacer(Modifier.height(12.dp))

                if (signal != null) {
                    Text("GOL SİNYALİ", color = Gold, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text("${signal.score}/100 • ${signal.label}", color = signalColor(signal), fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text("Baskı yönü: ${signal.leader}", color = Color.White, fontSize = 13.sp)
                    Text("${match.home}: ${signal.homePressure}/100  •  ${match.away}: ${signal.awayPressure}/100", color = Color.LightGray, fontSize = 12.sp)
                    signal.reasons.forEach { reason -> Text("• $reason", color = Color.LightGray, fontSize = 12.sp) }
                    Text("Bu skor bir olasılık veya garanti değil; canlı verilerden üretilen GOAL-X baskı endeksidir.", color = Color.Gray, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
                    Spacer(Modifier.height(14.dp))
                }

                if (detail == null || (detail.homeStats == null && detail.awayStats == null)) {
                    Text("Bu lig/maç için ayrıntılı istatistik henüz veri sağlayıcı tarafından sunulmamış olabilir.", color = Color.Gray, fontSize = 12.sp)
                } else {
                    Row(Modifier.fillMaxWidth()) {
                        Text(match.home, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.24f))
                        Text("MAÇ İSTATİSTİKLERİ", color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.52f))
                        Text(match.away, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.24f))
                    }
                    Spacer(Modifier.height(6.dp))
                    orderedStats(detail).forEach { type ->
                        StatRow(type, detail.homeStats?.values?.get(type), detail.awayStats?.values?.get(type))
                    }
                }

                if (!detail?.events.isNullOrEmpty()) {
                    Spacer(Modifier.height(12.dp))
                    Text("SON OLAYLAR", color = Gold, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    detail!!.events.takeLast(8).reversed().forEach { e ->
                        val who = listOf(e.team, e.player).filter { it.isNotBlank() }.joinToString(" • ")
                        Text("${e.minute}'  ${e.type} • ${e.detail}${if (who.isNotBlank()) " • $who" else ""}", color = Color.LightGray, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun App() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("goalx", 0) }
    var key by remember { mutableStateOf(prefs.getString("apiKey", "") ?: "") }
    var editing by remember { mutableStateOf(key.isBlank()) }
    var matches by remember { mutableStateOf<List<LiveMatch>>(emptyList()) }
    val details = remember { mutableStateMapOf<Int, MatchDetail>() }
    var loadingLive by remember { mutableStateOf(false) }
    var loadingStats by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var liveRefreshToken by remember { mutableIntStateOf(0) }
    var statsRefreshToken by remember { mutableIntStateOf(0) }
    var quotaRemaining by remember { mutableStateOf<Int?>(null) }
    var quotaLimit by remember { mutableStateOf<Int?>(null) }
    var lastStatsAt by remember { mutableLongStateOf(0L) }
    var expandedId by remember { mutableStateOf<Int?>(null) }
    var signalsOnly by remember { mutableStateOf(false) }

    LaunchedEffect(key, editing, liveRefreshToken) {
        if (key.isBlank() || editing) return@LaunchedEffect
        while (true) {
            loadingLive = true
            error = null
            try {
                val live = withContext(Dispatchers.IO) { fetchLive(key) }
                matches = live.matches
                quotaRemaining = live.quota.remaining ?: quotaRemaining
                quotaLimit = live.quota.limit ?: quotaLimit
                val liveIds = live.matches.map { it.id }.toSet()
                details.keys.toList().filterNot { it in liveIds }.forEach { details.remove(it) }

                val shouldRefreshStats = details.isEmpty() || System.currentTimeMillis() - lastStatsAt >= STATS_REFRESH_MS
                val enoughQuota = (quotaRemaining ?: 100) > 20
                if (shouldRefreshStats && enoughQuota && live.matches.isNotEmpty()) {
                    loadingStats = true
                    val rich = withContext(Dispatchers.IO) { fetchDetails(key, live.matches, quotaRemaining) }
                    details.putAll(rich.details)
                    quotaRemaining = rich.quota.remaining ?: quotaRemaining
                    quotaLimit = rich.quota.limit ?: quotaLimit
                    lastStatsAt = System.currentTimeMillis()
                    loadingStats = false
                }
            } catch (e: Exception) {
                error = e.message ?: "Bağlantı hatası"
            } finally {
                loadingLive = false
                loadingStats = false
            }
            val remaining = quotaRemaining ?: 100
            val wait = when {
                remaining <= 5 -> 900_000L
                remaining <= 20 -> 600_000L
                else -> LIVE_REFRESH_MS
            }
            delay(wait)
        }
    }

    LaunchedEffect(statsRefreshToken) {
        if (statsRefreshToken <= 0 || key.isBlank() || editing || matches.isEmpty() || loadingStats) return@LaunchedEffect
        loadingStats = true
        error = null
        try {
            val rich = withContext(Dispatchers.IO) { fetchDetails(key, matches, quotaRemaining) }
            details.putAll(rich.details)
            quotaRemaining = rich.quota.remaining ?: quotaRemaining
            quotaLimit = rich.quota.limit ?: quotaLimit
            lastStatsAt = System.currentTimeMillis()
        } catch (e: Exception) {
            error = e.message ?: "İstatistik verisi alınamadı"
        } finally {
            loadingStats = false
        }
    }

    val shownMatches = if (signalsOnly) {
        matches.filter { (details[it.id]?.signal?.score ?: 0) >= 70 }
    } else matches

    MaterialTheme {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            LazyColumn(
                Modifier.fillMaxSize().padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("GOAL-X AI", color = Gold, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                            Text("LIVE • V2.2 PRO SIGNAL", color = Color.LightGray)
                        }
                        TextButton(onClick = { editing = true }) { Text("API", color = Gold) }
                    }
                }

                if (editing) item {
                    Card(colors = CardDefaults.cardColors(containerColor = CardBg)) {
                        Column(Modifier.padding(16.dp)) {
                            Text("Canlı Futbol API Anahtarı", color = Color.White, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(8.dp))
                            OutlinedTextField(
                                value = key,
                                onValueChange = { key = it },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                label = { Text("API-Sports / API-Football key") }
                            )
                            Spacer(Modifier.height(8.dp))
                            Button(
                                onClick = {
                                    val clean = key.trim()
                                    prefs.edit().putString("apiKey", clean).apply()
                                    key = clean
                                    editing = false
                                    liveRefreshToken++
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("KAYDET VE CANLI MAÇLARI GETİR") }
                            Text("Anahtar yalnızca bu telefonda saklanır. GitHub projesine yazılmaz.", color = Color.Gray, fontSize = 12.sp)
                        }
                    }
                }

                if (key.isNotBlank() && !editing) item {
                    Card(colors = CardDefaults.cardColors(containerColor = SoftCard)) {
                        Column(Modifier.padding(14.dp)) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("${matches.size} canlı maç", color = Color.White, fontWeight = FontWeight.Bold)
                                Text(
                                    if (quotaRemaining != null) "API kotası: ${quotaRemaining}${quotaLimit?.let { "/$it" } ?: ""}" else "API kotası: —",
                                    color = if ((quotaRemaining ?: 100) <= 20) Orange else Green,
                                    fontSize = 12.sp
                                )
                            }
                            Text("İstatistikli maç: ${details.values.count { it.homeStats != null || it.awayStats != null }}", color = Color.LightGray, fontSize = 12.sp)
                            Text("Canlı skor ~5 dk, ayrıntılı istatistik ~30 dk aralıkla yenilenir; ücretsiz API kotasını korumak için kota azalınca uygulama otomatik yavaşlar.", color = Color.Gray, fontSize = 11.sp)
                            Spacer(Modifier.height(8.dp))
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(
                                    onClick = { liveRefreshToken++ },
                                    enabled = !loadingLive,
                                    modifier = Modifier.weight(1f)
                                ) { Text("CANLIYI YENİLE", fontSize = 11.sp) }
                                OutlinedButton(
                                    onClick = { statsRefreshToken++ },
                                    enabled = !loadingStats && matches.isNotEmpty() && (quotaRemaining ?: 100) > 5,
                                    modifier = Modifier.weight(1f)
                                ) { Text("SİNYALLERİ GÜNCELLE", fontSize = 11.sp) }
                            }
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                FilterChip(
                                    selected = !signalsOnly,
                                    onClick = { signalsOnly = false },
                                    label = { Text("TÜM MAÇLAR") }
                                )
                                FilterChip(
                                    selected = signalsOnly,
                                    onClick = { signalsOnly = true },
                                    label = { Text("YÜKSEK SİNYAL") }
                                )
                            }
                        }
                    }
                }

                if (loadingLive) item { LinearProgressIndicator(Modifier.fillMaxWidth(), color = Gold) }
                if (loadingStats) item {
                    Text("Canlı maç istatistikleri ve GOAL-X sinyalleri hesaplanıyor…", color = Gold, fontSize = 12.sp)
                    LinearProgressIndicator(Modifier.fillMaxWidth(), color = Orange)
                }

                error?.let { e ->
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF3A1717))) {
                            Column(Modifier.padding(16.dp)) {
                                Text("Veri alınamadı", color = Color.White, fontWeight = FontWeight.Bold)
                                Text(e, color = Color.LightGray, fontSize = 12.sp)
                                TextButton(onClick = { liveRefreshToken++ }) { Text("TEKRAR DENE") }
                            }
                        }
                    }
                }

                if (!loadingLive && error == null && key.isNotBlank() && matches.isEmpty()) {
                    item { Text("Şu anda API'de canlı maç görünmüyor.", color = Color.LightGray) }
                }

                if (signalsOnly && matches.isNotEmpty() && shownMatches.isEmpty()) {
                    item { Text("Şu anda 70+ GOAL-X sinyali görünmüyor. 'Sinyalleri Güncelle' ile tekrar tarayabilirsin.", color = Color.LightGray) }
                }

                shownMatches.groupBy { "${it.country} • ${it.league}" }.forEach { (league, leagueMatches) ->
                    item { Text(league, color = Gold, fontSize = 19.sp, fontWeight = FontWeight.Bold) }
                    items(leagueMatches, key = { it.id }) { m ->
                        MatchCard(
                            match = m,
                            detail = details[m.id],
                            expanded = expandedId == m.id,
                            onToggle = { expandedId = if (expandedId == m.id) null else m.id }
                        )
                    }
                }

                if (matches.isNotEmpty()) item {
                    Text(
                        "Not: API-Football her ligde her istatistiği sağlamayabilir. Eksik alanlar '—' olarak gösterilir. GOAL-X gol sinyali şut, isabetli şut, ceza sahası şutu, korner, topa sahip olma, xG ve kart gibi mevcut canlı verilerden üretilen bir baskı endeksidir; gol garantisi değildir.",
                        color = Color.Gray,
                        fontSize = 11.sp
                    )
                }
            }
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}
